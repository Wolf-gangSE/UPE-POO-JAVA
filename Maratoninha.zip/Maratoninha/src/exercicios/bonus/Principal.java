package exercicios.bonus;

import java.util.Scanner;

public class Principal {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int valor;
		int r100, r50, r20, r10, r5, r2, r1;
		int d100, d50, d20, d10, d5, d2, d1;
		int nota100 = 0, nota50 = 0, nota20 = 0, nota10 = 0, nota5 = 0, nota2=0, nota1 = 0;
		
		System.out.println("Digite o valor para saque (em R$): ");
		valor = s.nextInt();
		
		d100 = valor / 100;
		r100 = valor % 100;
		
		d50 = r100 / 50;
		r50 = r100 % 50;
		
		d20 = r50 / 20;
		r20 = r50 % 20;
		
		d10 = r20 / 10;
		r10 = r20 % 10;
		
		d5 = r10 / 5;
		r5 = r10 % 5;
		
		d2 = r5 / 2;
		r2 = r5 % 2;
		
		d1 = r2 / 1;
		r1 = r2 % 1;
		
		
		System.out.println("NOTAS DE R$100,00: " + d100);
		System.out.println("NOTAS DE R$50,00: " + d50);
		System.out.println("NOTAS DE R$20,00: " + d20);
		System.out.println("NOTAS DE R$10,00: " + d10);
		System.out.println("NOTAS DE R$5,00: " + d5);
		System.out.println("NOTAS DE R$2,00: " + d2);
		System.out.println("NOTAS DE R$1,00: " + d1);
	}

}
