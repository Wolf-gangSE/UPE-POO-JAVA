package exercicios.ex7;

import java.util.Random;
import java.util.Scanner;

/*  Elabore um algoritmo que inicie um sistema de vota��o
a) O sistema de vota��o deve durar 60 segundos
b) o sistema deve receber n�meros entre 0, 1, 2 e qualquer outro
c) se a resposta for 0, o voto � branco
d) se a resposta for 1, o voto � para a chapa 1
e) se a resposta for 2, o voto � para a chapa 2
f) se a resposta for qualquer outro n�mero, o voto � nulo
� No final deve ser informado quem venceu a elei��o (chapa 1 ou 2)
� E sumarizar a quantidade de votos para cada op��o. */

public class Principal {
	public static void main(String[] args) {
		try {
			int tempo = 60;
			int nulos = 0, brancos = 0, chapa1 = 0, chapa2 = 0;
			Random r = new Random(); //chama o comando random
			for (int i = 0; i < tempo; i++ ) {
				Thread.sleep(1000);//Realiza uma parada no processamento
				System.out.println("Os votos est�o sendo computados...");
				int voto = r.nextInt(4);
				switch (voto) { //o swtich � uma rotina de m�ltipla escolha (mesma l�gica que um if, elif e else)
				case 0:
					brancos++;
					break;
				case 1:
					chapa1++;
					break;
				case 2:
					chapa2++;
					break;
				default:
					nulos++;
					break;
				}
			}
			if (chapa1>chapa2) {
				System.out.println("Chapa 1 venceu!");
			}
			if (chapa2>chapa1) {
				System.out.println("Chapa 2 venceu!");
			} else {
				System.out.println("Ocorreu um empate entre as chapas!");
			}
			System.out.println("A quantidade de votos nulos foi: " + nulos);
			System.out.println("A quantidade de votos brancos foi: " + brancos);
			System.out.println("A quantidade de votos para chapa 1 foi: " + chapa1);
			System.out.println("A quantidade de votos para chapa 2 foi: " + chapa2);
		} catch(Exception e) {
			
		}
	}
}