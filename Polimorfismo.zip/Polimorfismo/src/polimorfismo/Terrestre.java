package polimorfismo;

public interface Terrestre {
	void andar();
	void tipificar();

}
