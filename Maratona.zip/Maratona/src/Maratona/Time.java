package Maratona;

public class Time extends Jogo{
	public String nome;
	public int pontos;
	public int fatortecnica;
	
	public Time (String nome, int pontos, int fatortecnica) {
		this.nome = nome;
		this.pontos = pontos;
		this.fatortecnica = fatortecnica;
	}
	
}
